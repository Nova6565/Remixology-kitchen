package advanced;

import java.util.*;
import java.io.Serializable;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
public class User implements Serializable{
		Database d=new Database();
		String firstname;
		String lastname;
		java.sql.Date date;
		String gender;
		String email;
		String password;
		int id;
		public User() {}
		public User(String firstname,String lastname, int age, String gender) {
			super();
			this.firstname = firstname;
			this.lastname=lastname;
			//this.age = age;
			this.gender = gender;
		}
		
		public Date getDate() {
			return date;
		}
		public void setDate(String date) {
			System.out.println(date+"   setDate");
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		    java.util.Date utilDate = null;
			try {
				utilDate = sdf.parse(date);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		    java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
		    this.date=sqlDate;
		}
		public String getFirstname() {
			return firstname;
		}
		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}
		public String getLastname() {
			return lastname;
		}
		public void setLastname(String lastname) {
			this.lastname = lastname;
		}
		public ArrayList<Ingredients> getIngredients() {
			return ingredients;
		}
		public void setIngredients(ArrayList<Ingredients> ingredients) {
			this.ingredients = ingredients;
		}
		public ArrayList<Recipe> getRecipes() {
			return recipes;
		}
		public void setRecipes(ArrayList<Recipe> recipes) {
			this.recipes = recipes;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getPassword() {
			return password;
		}
		public void setPassword(String password) {
			this.password = password;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		void register(String email,String password) {
			this.email=email;
			System.out.print("Confirm your password: ");
			if(password.compareTo("")==0) {//ha5odha getparameter JSP ya3ny
				this.password = password;
				d.InsertUser(this);
			}
			else {
				System.out.println("It didn't match\nTo try again press 1 else press 0");
			}
			
		}

		ArrayList<Ingredients> ingredients=new ArrayList<Ingredients>();
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		public void addIngredient(Ingredients i) {
			ingredients.add(i);
		}
		public void addRecipeFavourites(Recipe r) {
			d.InsertClientFav(this, r);
		}
		public void chooseRecipe(Recipe r,float rt) {
			r.addRate(rt);
		}
		public ArrayList<Recipe> seaechByIngredients(){//implemintation is right but it needs an interface
			ArrayList<Recipe> recipes=d.AllRecipes();
			System.out.println(recipes);
			ArrayList<Recipe> f=new ArrayList<Recipe>(); 
			HashMap<Recipe,Integer> map=new HashMap<Recipe, Integer>();
			int c;
			for(Recipe r: recipes) {
				c=0;
				r.setIngredients(d.getRecipeIng(r));
				System.out.println("HII "+r.getIngredients());
				System.out.println("byy "+ingredients);
				for(Ingredients i : ingredients) {
					for(Ingredients j:r.getIngredients()) {
						if(j==null)continue;
						if(i.getName().equals(j.getName())) {
							c++;
						}
					}
				}
				System.out.println(c);
				map.put(r, c);
			}
			HashMap<Recipe,Integer> s= sortHash(map);
			int x=1;
			for (Map.Entry<Recipe, Integer> set : s.entrySet()) {
				if(x==5) {
					break;
				}
				if(x==1&&set.getValue()==0) {
					return null;
				}
				else if(set.getValue()>0) {
					f.add(set.getKey());
					x++;
				}
				else {
					break;
				}
			}
			return f;
		}
		
		private HashMap<Recipe, Integer> sortHash(HashMap<Recipe, Integer> hm) {
			  	List<Map.Entry<Recipe, Integer> > list =
		        new LinkedList<Map.Entry<Recipe, Integer> >(hm.entrySet());
		        Collections.sort(list, new Comparator<Map.Entry<Recipe, Integer> >() {
		            public int compare(Map.Entry<Recipe, Integer> o1, 
		                               Map.Entry<Recipe, Integer> o2)
		            {
		                return (o1.getValue()).compareTo(o2.getValue());
		            }
		        });
		        Collections.reverse(list);
		        HashMap<Recipe, Integer> temp = new LinkedHashMap<Recipe, Integer>();
		        for (Map.Entry<Recipe, Integer> aa : list) {
		            temp.put(aa.getKey(), aa.getValue());
		        }
		        return temp;
		}
		void deleteIngredient(String name) {//implemintation is right but it needs an interface
			Ingredients i=new Ingredients();
			i.setName(name);
			if(ingredients.contains(i)) {
				ingredients.remove(i);
			}
			else {
				System.out.println("It wasn't found anyway");
			}
		}
		void searchRecipe(String name) {
			ArrayList<Recipe> r=d.searchRecipeName(name);
			if(r==null) {
				System.out.println("There are no recipes with such name!");
			}
			else {
				//Previewwww
			}
		}

		@Override
		public String toString() {
			return "User [firstname=" + firstname + ", lastname=" + lastname + ", date=" + date + ", gender=" + gender
					+ ", email=" + email + ", password=" + password + ", id=" + id + "]";
		}
		
		void deleteRecipe(String name,int carb,int protein,int fats) {//needs some updates
			Recipe r=new Recipe();
			r.setCarb(carb);
			r.setFats(fats);
			r.setName(name);
			r.setProtein(protein);
			if(recipes.contains(r)) {
				recipes.remove(r);
			}
			else {
				System.out.println("The recipe wasn't found");
			}
		}
		float avgRate() {
			int c=0;
			float sum=0;
			for(Recipe r: recipes) {
				c++;
				sum+=r.getRate();
			}
			return sum/c;
		}
		
}


