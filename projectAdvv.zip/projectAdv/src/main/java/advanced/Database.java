package advanced;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.Collections;

public class Database implements Serializable{//all data insertions and retreivals are working but some of the other methods needs some editing like (edit recipe/delete recipe/add rating/top users)
	
	Connection con = null;
	Statement smt = null;
	PreparedStatement psmt = null;
	public Database() {
		try {
			System.out.println("SUIIIIII");
			Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			//smt.executeUpdate("ALTER TABLE users ADD id INT UNSIGNED NOT NULL AUTO_INCREMENT ADD INDEX (user_id);");
			this.createTables();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	
	/*public Database(){
		try {
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            con = DriverManager.getConnection("jdbc:derby:IZEE_TESTING_May_2;create=true");
        } catch(ClassNotFoundException | SQLException e) {
        	e.printStackTrace();
        }
	}*/
	public void createTables() {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			smt=con.createStatement();
			/*smt.executeUpdate("INSERT INTO Users(firstname, lastname, birthdate, gender, email, password) VALUES " +
				    "('Mohamed', 'Ali', '1993-03-15', 'Male', 'mohamed@example.com', 'secret'), " +
				    "('Fatima', 'Khalid', '1988-07-22', 'Female', 'fatima@example.com', 'password'), " +
				    "('Ahmed', 'Mahmoud', '1990-11-10', 'Male', 'ahmed@example.com', '123456'), " +
				    "('Nour', 'Saleh', '1995-04-03', 'Female', 'nour@example.com', 'password123'), " +
				    "('Abdullah', 'Ahmed', '1986-09-28', 'Male', 'abdullah@example.com', 'test'), " +
				    "('Sara', 'Ahmed', '1992-07-17', 'Female', 'sara@example.com', 'hello'), " +
				    "('Mahmoud', 'Ali', '1989-12-06', 'Male', 'mahmoud@example.com', 'password123'), " +
				    "('Layla', 'Abdulrahman', '1994-02-19', 'Female', 'layla@example.com', '12345678'), " +
				    "('Yousef', 'Mohammed', '1991-06-24', 'Male', 'yousef@example.com', 'welcome'), " +
				    "('Maryam', 'Khalid', '1987-10-31', 'Female', 'maryam@example.com', 'welcome123')");*/

				/*smt.executeUpdate("INSERT INTO Recipe (recipe_name, calories, rating, protein, carbohydrates, fats, numUsers, description, user_id) VALUES " +
				    "('Banana Smoothie', 200, 0, 5, 35, 2, 10, 'Refreshing smoothie made with bananas.', 22100), " +
				    "('Vegetable Curry', 300, 0, 10, 25, 15, 8, 'Delicious curry with mixed vegetables.', 22100), " +
				    "('Salmon Salad', 250, 0, 20, 10, 12, 6, 'Healthy salad with grilled salmon.', 22100), " +
				    "('Tofu Stir Fry', 220, 0, 15, 30, 8, 5, 'Flavorful stir-fry with tofu and vegetables.', 22100), " +
				    "('Chicken Pasta', 400, 0, 25, 30, 18, 9, 'Classic pasta dish with chicken and tomato sauce.', 22100), " +
				    "('Greek Yogurt Parfait', 180, 0, 8, 20, 5, 7, 'Healthy parfait made with Greek yogurt and fruits.', 22100), " +
				    "('Cheese Omelette', 350, 0, 20, 5, 25, 8, 'Delicious omelette with cheese and vegetables.', 22100), " +
				    "('Fruit Salad', 150, 0, 2, 30, 1, 6, 'Fresh fruit salad with assorted fruits.', 22100), " +
				    "('Spicy Chicken Curry', 380, 0, 30, 25, 20, 12, 'Fiery chicken curry with a blend of spices.', 22100), " +
				    "('Pineapple Fried Rice', 320, 0, 10, 40, 15, 10, 'Tasty fried rice with pineapple and vegetables.', 22100)");*/

			smt.executeUpdate("INSERT INTO RecipeIngredients(recipe_id, ingredient_name) VALUES " +
				    "(23411, 'Banana'), " +
				    "(23411, 'Carrot'), " +
				    "(23411, 'Apple'), " +
				    "(23411, 'Lemon'), " +
				    "(23411, 'Onion'), " +
				    "(23412, 'Garlic'), " +
				    "(23412, 'Strawberry'), " +
				    "(23412, 'Broccoli'), " +
				    "(23412, 'Tomato'), " +
				    "(23412, 'Cucumber'), " +
				    "(23413, 'Ginger'), " +
				    "(23413, 'Cinnamon'), " +
				    "(23413, 'Parsley'), " +
				    "(23414, 'Vinegar'), " +
				    "(23414, 'Coriander'), " +
				    "(23414, 'Bay Leaf'), " +
				    "(23414, 'Rosemary'), " +
				    "(23415, 'Curry'), " +
				    "(23415, '7 spices'), " +
				    "(23415, 'Salt'), " +
				    "(23415, 'Paprika'), " +
				    "(23416, 'Chicken breast'), " +
				    "(23416, 'Salmon fillet'), " +
				    "(23416, 'Tofu'), " +
				    "(23416, 'Lean beef steak'), " +
				    "(23417, 'Eggs'), " +
				    "(23417, 'Fish'), " +
				    "(23417, 'Tuna'), " +
				    "(23417, 'Greek yogurt'), " +
				    "(23417, 'Cottage cheese'), " +
				    "(23418, 'Quinoa'), " +
				    "(23418, 'Lentils'), " +
				    "(23418, 'Milk'), " +
				    "(23418, 'Oil'), " +
				    "(23419, 'Olive oil'), " +
				    "(23419, 'Water'), " +
				    "(23419, 'Pasta'), " +
				    "(23419, 'Bread'), " +
				    "(23419, 'Butter'), " +
				    "(23420, 'Cheese'), " +
				    "(23420, 'Chicken stock'), " +
				    "(23420, 'Yogurt'), " +
				    "(23420, 'Cumin'), " +
				    "(23421, 'Mango'), " +
				    "(23421, 'Grapes'), " +
				    "(23421, 'Pineapple'), " +
				    "(23421, 'Watermelon'), " +
				    "(23421, 'Kiwi'), " +
				    "(23422, 'Pear'), " +
				    "(23422, 'Peach'), " +
				    "(23422, 'Blueberry'), " +
				    "(23422, 'Cherry'), " +
				    "(23422, 'Raspberry'), " +
				    "(23423, 'Cantaloupe'), " +
				    "(23423, 'Apricot'), " +
				    "(23423, 'Plum'), " +
				    "(23423, 'Coconut'), " +
				    "(23423, 'Dragon fruit'), " +
				    "(23424, 'Baking powder'), " +
				    "(23424, 'Toast'), " +
				    "(23424, 'Cereal'), " +
				    "(23424, 'Basmati rice'), " +
				    "(23425, 'Brown rice'), " +
				    "(23425, 'White rice'), " +
				    "(23425, 'Barley'), " +
				    "(23425, 'Couscous'), " +
				    "(23425, 'Black pepper'), " +
				    "(23426, 'Orange')");




			smt.executeUpdate("CREATE TABLE Clients_FavRecipies (\r\n"
					+ "    user_id INTEGER,\r\n"
					+ "    recipe_id INTEGER,\r\n"
					+ "    PRIMARY KEY (user_id, recipe_id),\r\n"
					+ "    FOREIGN KEY (recipe_id) REFERENCES Recipe(recipe_id),\r\n"
					+ "    FOREIGN KEY (user_id) REFERENCES Users(user_id)\r\n"
					+ ")");
			smt.executeUpdate("CREATE TABLE Users (\r\n"
					+ "    user_id INTEGER  GENERATED ALWAYS AS IDENTITY (START WITH 22100) PRIMARY KEY,\r\n"
					+ "    firstname VARCHAR(30) NOT NULL,\r\n"
					+ "    lastname VARCHAR(30) NOT NULL,\r\n"
					+ "    birthdate DATE NOT NULL,\r\n"
					+ "    gender VARCHAR(20),\r\n"
					+ "    email VARCHAR(50) NOT NULL,\r\n"
					+ "    password VARCHAR(20) NOT NULL\r\n"
					+ ")");
			
			smt.executeUpdate("CREATE TABLE Recipe (" +
                    "recipe_id INTEGER  GENERATED ALWAYS AS IDENTITY (START WITH 22100) PRIMARY KEY," + 
                    "recipe_name VARCHAR(30) NOT NULL," +
                    "calories INTEGER NOT NULL," +
                    "rating FLOAT NOT NULL," +
                    "protein INTEGER NOT NULL," +
                    "carbohydrates INTEGER NOT NULL," +
                    "fats INTEGER NOT NULL," +
                    "numUsers INTEGER," +
                    "description VARCHAR(1000)," +
                    "user_id INTEGER," +
                    "FOREIGN KEY (user_id) REFERENCES Users(user_id)" +
                    ")");
			
			smt.executeUpdate("CREATE TABLE RecipeIngredients (" +
                    "recipe_id INTEGER," +
                    "ingredient_name VARCHAR(20)," + // Change from ingredients_name to ingredient_name
                    "PRIMARY KEY (recipe_id, ingredient_name))");
			
			
			smt.executeUpdate("CREATE TABLE ingredients ("
					+ "    ingredient_name VARCHAR(20) NOT NULL,\r\n"
					+ "    category VARCHAR(20),\r\n"
					+ "    PRIMARY KEY (ingredient_name)\r\n"
					+ ")");
			
			
			
			
					

			
			
			//smt.executeUpdate("drop table RECIPE");*/

		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	public ArrayList<Recipe> getFav(User u){
		ArrayList<Recipe>recipes=new ArrayList<Recipe>();
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select recipe_id from Clients_FavRecipies where user_id=?");
			psmt.setInt(1, u.getId());
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				recipes.add(this.searchRecipe(rs.getInt(1)));
			}
			return recipes;
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	public int isFavfound(User u,int id) {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from Clients_FavRecipies where user_id = ? and recipe_id = ?");
			psmt.setInt(1, u.getId());
			psmt.setInt(2, id);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				return 1;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return 0;

	}
	public int insertFav(User r,int id) {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("INSERT INTO Clients_FavRecipies(user_id,recipe_id) VALUES (?,?)");
			psmt.setInt(1, r.getId());
			psmt.setInt(2, id);
			return psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return 0;
	}
	public ArrayList<Ingredients> getIngRec(Recipe r){
		ArrayList<Ingredients> ing=new ArrayList<Ingredients>();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select ingredient_name from User where recipe_id =?");
			psmt.setInt(1, r.getId());
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				Ingredients i=this.isInfFound(rs.getString(1));
				ing.add(i);
			}
			return ing;
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	public int editRecipe(Recipe r) {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			psmt=con.prepareStatement("update recipe SET carbohydrates = ?, calories = ?, fats = ?, protein = ?, recipe_name = ?, description = ? WHERE recipe_id = ?");
			//psmt = con.prepareStatement("UPDATE recipe SET carbohydrates = ?, calories = ?, fats = ?, protein = ?, name = ?, description = ? WHERE recipe_id = ?");
			psmt.setInt(1, r.getCarb());
			psmt.setInt(2, r.getCalories());
			psmt.setInt(3, r.getFats());
			psmt.setInt(4, r.getProtein());
			psmt.setString(5,r.getName());
			psmt.setString(6,r.getDescription());
			psmt.setInt(7, r.getId());
			return psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return 0;
	}
	public User searchU(int i) {
		User ch=new User();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from User where user_id =?");
			psmt.setInt(1, i);
			ResultSet s=psmt.executeQuery();
			if(s.next()) {
				ch.setId(s.getInt(1));
				ch.setFirstname(s.getString(2));
				ch.setLastname(s.getString(3));
				ch.setDate(s.getString(4));
				ch.setGender(s.getString(5));
				ch.setEmail(s.getString(6));
				ch.setPassword(s.getString(7));
				System.out.println(ch.toString());
				return ch;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	public int InsertUser(User u) {
		int i=0;
		try {
			con= DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("Insert into Users(firstname,lastname,birthdate,gender,email,password) values(?,?,?,?,?,?)");
			psmt.setString(1, u.getFirstname());
			psmt.setString(2, u.getLastname());
			psmt.setDate(3, u.getDate());
			System.out.println(u.getDate());
			psmt.setString(4, u.getGender());
			psmt.setString(5, u.getEmail());
			psmt.setString(6, u.getPassword());
			i= psmt.executeUpdate();
			System.out.println("Success");
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return i;
	}
	public ArrayList<Recipe> userRecipes(User u){
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		try {
			int f=0;
			con= DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from recipe where user_id=?");
			psmt.setInt(1, u.getId());
			ResultSet rs=psmt.executeQuery();
			System.out.println("broo");
			while(rs.next()) {
				System.out.println("yaaaay");
				f=1;
				Recipe r=new Recipe();
				r.setId(rs.getInt(1));
				r.setName(rs.getString(2));
				r.setCalories(rs.getInt(3));
				r.setRate(rs.getFloat(4));
				r.setProtein(rs.getInt(5));
				r.setCarb(rs.getInt(6));
				r.setFats(rs.getInt(7));
				r.setPeopleUsed(rs.getInt(8));
				r.setDescription(rs.getString(9));
				recipes.add(r);
			}
			if(f==1)
				return recipes;
			else
				return null;
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	public void editRate(Recipe r) {
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			psmt=con.prepareStatement("update Recipe set rate= ? where name = ?");
			psmt.setFloat(1, r.getRate());
			psmt.setString(2, r.getName());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	public void recipeIng(Recipe r,String name) {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("INSERT INTO RecipeIngredients(recipe_id,ingredient_name) VALUES (?,?)");
			psmt.setInt(1, r.getId());
			psmt.setString(2, name);
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	public ArrayList<Ingredients> getRecipeIng(Recipe r) {
		ArrayList<Ingredients> ing=new ArrayList<Ingredients>();
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select ingredient_name from RecipeIngredients where recipe_id=?");
			psmt.setInt(1, r.id);
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				ing.add(this.getIng(rs.getString(1)));
			}
			rs.close();
			return ing;
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	public String printIng(Recipe r) {
		String str="";
		r.ingredients=this.getRecipeIng(r);
		for(Ingredients i: r.ingredients) {
			if(i==null)continue;
			str+=i.getName()+", ";
		}
		return str;
	}
	public int InsertRecipe1(Recipe r) {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			psmt=con.prepareStatement("INSERT INTO Recipe (recipe_name, calories, rating, protein, carbohydrates, fats, numUsers, description,user_id) VALUES (?,?,?,?,?,?,?,?,?)");
			psmt.setString(1, r.getName());
			psmt.setInt(2, r.getCalories());
			psmt.setFloat(3, r.getRate());
			psmt.setInt(4, r.getProtein());
			psmt.setInt(5, r.getCarb());
			psmt.setInt(6, r.getFats());
			psmt.setInt(7, r.getPeopleUsed());
			psmt.setString(8, r.getDescription());
			psmt.setInt(9, r.getUser().id);
		    int i=psmt.executeUpdate();
		    return i;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return 0;
	}
	public Ingredients isInfFound(String name) {
		Ingredients i=new Ingredients();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from ingredients where ingredients_name = ?");
			psmt.setString(1, name);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				i.setName(rs.getString(1));
				i.setCategory(rs.getString(2));
			}
			return i;
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return i;
	}
	public ArrayList<Ingredients> allIngredients() {
		ArrayList<Ingredients> ing=new ArrayList<Ingredients>();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from ingredients");
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				Ingredients i=new Ingredients();
				i.setName(rs.getString(1));
				i.setCategory(rs.getString(2));
				ing.add(i);
			}
			rs.close();
			return ing;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return ing;
	}
	public void insertIngredient(String i,String j) {
		try {
			con=DriverManager.getConnection("jdbc:derby:db/NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("Insert into ingredients values(?,?)");
			psmt.setString(1, i);
			psmt.setString(2, j);
			psmt.executeUpdate();
			psmt.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	public Ingredients getIng(String name) {
		Ingredients i=new Ingredients();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from ingredients where ingredients_name=?");
			psmt.setString(1, name);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				i.setName(rs.getString(1));
				i.setCategory(rs.getString(2));
				return i;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	public ArrayList<User> allUsers(){
		ArrayList<User> users=new ArrayList<User>();
		try {
			
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			psmt=con.prepareStatement("select * from Users");
			ResultSet s=psmt.executeQuery();
			while(s.next()) {
				User ch=new User();
				ch.setId(s.getInt(1));
				ch.setFirstname(s.getString(2));
				ch.setLastname(s.getString(3));
				ch.setDate(s.getString(4));
				ch.setGender(s.getString(5));
				ch.setEmail(s.getString(6));
				ch.setPassword(s.getString(7));
				System.out.println(ch.toString());
				users.add(ch);
			}
			s.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return users;
	}
	public User Login(User u) {
		try {
			if(emailFound(u.getEmail())) {
				System.out.println("Email found");
				con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
				 psmt=con.prepareStatement("SELECT * FROM Users WHERE Email=?");
		            psmt.setString(1, u.email);
		            ResultSet s= psmt.executeQuery();
		            if(!s.next()) {
		            	System.out.println("Nothing found bruv");
		            }
				if(u.getPassword().equals(s.getString(7))) {
					System.out.println("Pass right");
					u.setId(s.getInt(1));
					u.setFirstname(s.getString(2));
					u.setLastname(s.getString(3));
					u.setDate(s.getString(4));
					u.setGender(s.getString(5));
					u.setEmail(s.getString(6));
					u.setPassword(s.getString(7));
					return u;
				}
				else {
					System.out.println("Wrong pass");
					return null;
				}
			}
			else {
				return null;
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	void insertFavourites(User c,Recipe r) {
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			psmt=con.prepareStatement("Insert into Client's_FavRecipies values(?,?)");
			psmt.setInt(1, c.getId());
			psmt.setString(2, r.getName());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	public int deleteRecipe(int id) {
		try {
			con= DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("delete from recipe where recipe_id=?");
			psmt.setInt(1, id);
			return psmt.executeUpdate();
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return 0;
	}
	public int deleteIng(int id) {
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("delete from RecipeIngredients where recipe_id=?");
			psmt.setInt(1, id);
			return psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return 0;
	}
	
	public Recipe searchRecipe(int id) {
		Recipe r=new Recipe();
		try {
			con= DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
			psmt=con.prepareStatement("select * from recipe where recipe_id=?");
			psmt.setInt(1, id);
			ResultSet rs=psmt.executeQuery();
			if(rs.next()) {
				r.setId(rs.getInt(1));
				r.setName(rs.getString(2));				
				r.setCalories(rs.getInt(3));
				r.setRate(rs.getFloat(4));
				r.setProtein(rs.getInt(5));
				r.setCarb(rs.getInt(6));
				r.setFats(rs.getInt(7));
				r.setPeopleUsed(rs.getInt(8));
				r.setDescription(rs.getString(9));
				return r;
			}
			else {
				return null;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return r;
	}
	public ArrayList<Recipe> AllRecipes(){
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			psmt=con.prepareStatement("select * from recipe");
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				Recipe r=new Recipe();
				r.setId(rs.getInt(1));
				r.setName(rs.getString(2));
				r.setCalories(rs.getInt(3));
				r.setRate(rs.getFloat(4));
				r.setProtein(rs.getInt(5));
				r.setCarb(rs.getInt(6));
				r.setFats(rs.getInt(7));
				r.setPeopleUsed(rs.getInt(8));
				r.setDescription(rs.getString(9));
				/*User ch=new User();
				psmt=con.prepareStatement("select * from Users where user_id=?");
				psmt.setInt(1, rs.getInt(10));
				rs.close();
				rs=psmt.executeQuery();
				ch.setId(rs.getInt(1));
				ch.setFirstname(rs.getString(2));
				ch.setLastname(rs.getString(3));
				ch.setDate(rs.getString(4));
				ch.setGender(rs.getString(5));
				ch.setEmail(rs.getString(6));
				ch.setPassword(rs.getString(7));*/
				recipes.add(r);
			}
			return recipes;
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return recipes;
	}
	public ArrayList<Recipe> chiefRecipes(User c){
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			psmt=con.prepareStatement("select * from Recipe where chief_Id = ?");
			psmt.setInt(1, c.getId());
			ResultSet rs=psmt.executeQuery();
			if(!rs.next()) {
				return null;
			}
			else {
				while(rs.next()) {
					Recipe r=new Recipe();
					r.setName(rs.getString(1));				
					r.setCalories(rs.getInt(2));
					r.setRate(rs.getFloat(3));
					r.setProtein(rs.getInt(4));
					r.setCarb(rs.getInt(5));
					r.setFats(rs.getInt(6));
					r.setPeopleUsed(rs.getInt(7));
					psmt=con.prepareStatement("select * from User where id=?");
					psmt.setInt(1, rs.getInt(8));
					ResultSet s=psmt.executeQuery();
					User ch=new User();
					ch.setId(s.getInt(1));
					ch.setFirstname(s.getString(2));
					ch.setLastname(s.getString(3));
					ch.setDate(s.getString(4));
					ch.setGender(s.getString(5));
					ch.setEmail(s.getString(6));
					ch.setPassword(s.getString(7));
					r.setUser(ch);
					recipes.add(r);
				}
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		
		}
		return recipes;
	}
	public ArrayList<Recipe> topProtein(){
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			smt=con.createStatement();
			ResultSet rs= smt.executeQuery("SELECT * FROM Users ORDER BY protein DESC");
			while(rs.next()) {
				Recipe r=new Recipe();
				r.setName(rs.getString(1));				
				r.setCalories(rs.getInt(2));
				r.setRate(rs.getFloat(3));
				r.setProtein(rs.getInt(4));
				r.setCarb(rs.getInt(5));
				r.setFats(rs.getInt(6));
				r.setPeopleUsed(rs.getInt(7));
				psmt=con.prepareStatement("select * from User where id=?");
				psmt.setInt(1, rs.getInt(8));
				ResultSet s=psmt.executeQuery();
				User ch=new User();
				ch.setId(s.getInt(1));
				ch.setFirstname(s.getString(2));
				ch.setLastname(s.getString(3));
				ch.setDate(s.getString(4));
				ch.setGender(s.getString(5));
				ch.setEmail(s.getString(6));
				ch.setPassword(s.getString(7));
				r.setUser(ch);
				recipes.add(r);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return recipes;
	}
	public ArrayList<Recipe> lowestCalories(){
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			smt=con.createStatement();
			ResultSet rs= smt.executeQuery("SELECT * FROM Users ORDER BY calories");
			while(rs.next()) {
				Recipe r=new Recipe();
				r.setName(rs.getString(1));				
				r.setCalories(rs.getInt(2));
				r.setRate(rs.getFloat(3));
				r.setProtein(rs.getInt(4));
				r.setCarb(rs.getInt(5));
				r.setFats(rs.getInt(6));
				r.setPeopleUsed(rs.getInt(7));
				psmt=con.prepareStatement("select * from User where id=?");
				psmt.setInt(1, rs.getInt(8));
				ResultSet s=psmt.executeQuery();
				User ch=new User();
				ch.setId(s.getInt(1));
				ch.setFirstname(s.getString(2));
				ch.setLastname(s.getString(3));
				ch.setDate(s.getString(4));
				ch.setGender(s.getString(5));
				ch.setEmail(s.getString(6));
				ch.setPassword(s.getString(7));
				r.setUser(ch);
				recipes.add(r);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return recipes;
	}
	public void InsertClientFav(User user,Recipe r) {
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			psmt=con.prepareStatement("Inser into Client's_FavRecipies values(?,?)");
			psmt.setInt(1, user.getId());
			psmt.setString(2, r.getName());
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}
	public boolean emailFound(String email) {
		boolean f=false;
        try {
            System.out.println("Before Trying to connect to DB");

			con= DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");
            System.out.println("Connection Succes Before Trying to Excute query");

            psmt=con.prepareStatement("SELECT * FROM Users WHERE Email=?");
            psmt.setString(1, email);
            ResultSet rs= psmt.executeQuery();
            System.out.println("Before If Condition");
            if(rs.next()) {
                System.out.println("Inside If Condition (Method Returned True)");
                return f=true;
            }
            else {
                System.out.println("outside If Condition (Method Returned false)");
                return f=false;
            }
        }catch(Exception e) {
            e.printStackTrace();
        }
        finally {
            if(con!=null) {
                try {
                    con.close();
                } catch (SQLException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            }
        }
        System.out.println("outside If Condition (Method Returned false)");

        return f;
	}
	public User checkPassword(String email,String password) {
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			psmt=con.prepareStatement("select * from Users where email = ?");
			psmt.setString(1, email);
			ResultSet rs= psmt.executeQuery();
			if(password.equals(rs.getString(7))) {
				User ch=new User();
				ch.setId(rs.getInt(1));
				ch.setFirstname(rs.getString(2));
				ch.setLastname(rs.getString(3));
				ch.setDate(rs.getString(4));
				ch.setGender(rs.getString(5));
				ch.setEmail(rs.getString(6));
				ch.setPassword(rs.getString(7));
				return ch;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return null;
	}
	public void updateRecipName(String value,Recipe r) {
		try {
			con=DriverManager.getConnection("jdbc:derby:db/Recipes;create=true");
			psmt=con.prepareStatement("UPDATE Recipe\r\n"
					+ "SET name = ?\r\n"
					+ "WHERE id=?;");
			psmt.setString(1, value);
			psmt.setInt(2,r.getId());
			psmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
	}

	public ArrayList<Recipe> searchRecipeName(String name) {
		Recipe r=new Recipe();
		ArrayList<Recipe> recipes=new ArrayList<Recipe>();
		try {
			con = DriverManager.getConnection("jdbc:derby:NOVA1_TESTING;create=true");	
			psmt=con.prepareStatement("select * from recipe where recipe_name like ?");	
			psmt.setString(1, name);
			ResultSet rs=psmt.executeQuery();
			while(rs.next()) {
				r.setId(rs.getInt(1));
				r.setName(rs.getString(2));				
				r.setCalories(rs.getInt(3));
				r.setRate(rs.getFloat(4));
				r.setProtein(rs.getInt(5));
				r.setCarb(rs.getInt(6));
				r.setFats(rs.getInt(7));
				r.setPeopleUsed(rs.getInt(8));
				r.setDescription(rs.getString(9));
				recipes.add(r);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		}
		return recipes;
	}
	
}

