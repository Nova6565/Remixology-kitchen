package advanced;
import java.util.ArrayList;
public class Main {
	public static void main(String[]args) {
		Database db=new Database();
		ArrayList<Recipe> i=db.AllRecipes();
		System.out.println(i);
	}
}
