package advanced;

import java.io.Serializable;
import java.util.ArrayList;

public class Recipe implements Serializable {
	String name;
	int carb;
	int protein;
	int fats;
	int calories;
	int id;
	ArrayList<Ingredients>ingredients= new ArrayList<Ingredients>();
	float rate=0;
	int peopleUsed=0;
	String description;
	User chief;
	Database d;
	public Recipe(){
	}
	
	public ArrayList<Ingredients> getIngredients() {
		return ingredients;
	}



	public void setIngredients(ArrayList<Ingredients> ingredients) {
		this.ingredients = ingredients;
	}



	public User getChief() {
		return chief;
	}

	public void setChief(User chief) {
		this.chief = chief;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCarb() {
		return carb;
	}
	public void setCarb(int carb) {
		this.carb = carb;
	}
	public int getProtein() {
		return protein;
	}
	public void setProtein(int protein) {
		this.protein = protein;
	}
	public int getFats() {
		return fats;
	}
	public void setFats(int fats) {
		this.fats = fats;
	}
	public int getCalories() {
		return calories;
	}
	public void setCalories(int calories) {
		this.calories = calories;
	}
	public float getRate() {
		return rate;
	}
	public void setRate(float rate) {
		this.rate = rate;
	}
	public int getPeopleUsed() {
		return peopleUsed;
	}
	public void setPeopleUsed(int peopleUsed) {
		this.peopleUsed = peopleUsed;
	}
	public User getUser() {
		return chief;
	}
	public void setUser(User chief) {
		this.chief = chief;
	}
	public void calcCalories() {
		this.calories= (protein*4)+(carb*4)+(fats*9);
	}
	public void addRate(float x) {
		peopleUsed++;
		rate+=x/peopleUsed;
		if(rate>5) {
			rate=5;
		}
		d.editRate(this);
	}
	public int insertRecipe() {
		return d.InsertRecipe1(this);
	}
	public void addIngredient(Ingredients i) {
		ingredients.add(i);
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	
}

