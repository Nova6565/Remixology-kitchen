package advanced;

import java.io.Serializable;

public class Ingredients implements Serializable {
	String name;
	String category;
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public Ingredients() {
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Ingredients [name=" + name + ", category=" + category + "]";
	}
	
	
}

